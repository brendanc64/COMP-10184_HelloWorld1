#include <Arduino.h>

unsigned long myTime;

int chipID = ESP.getChipId();
int flashID = ESP.getFlashChipId();

void setup() {
  // put your setup code here, to run once:

  Serial.begin(115200);

  Serial.println("\nBrendan Crawford 000832017");
  Serial.println("\n\tI. ");
  Serial.print(chipID);
  Serial.println("\n\tII. ");
  Serial.print(flashID);


}

void loop() {
  // put your main code here, to run repeatedly:
  Serial.println("\n\t\tTime: ");
  myTime = millis();

  Serial.println(myTime);
  delay(2000);
}